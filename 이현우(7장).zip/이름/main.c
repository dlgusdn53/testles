#include <stdio.h>
#include <stdlib.h>

// ============================================================
// 원형 연결 리스트 노드 (문제 03, 04)
// ============================================================
typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

// 원형 연결 리스트에 노드 추가 (tail 반환)
ListNode* addToCircular(ListNode* tail, int data) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    newNode->data = data;
    if (tail == NULL) {
        newNode->next = newNode; // 자기 자신을 가리킴
        return newNode;
    }
    newNode->next = tail->next;
    tail->next = newNode;
    return newNode;
}

// 원형 연결 리스트 출력
void printCircular(ListNode* tail) {
    if (tail == NULL) { printf("(빈 리스트)\n"); return; }
    ListNode* cur = tail->next;
    do {
        printf("%d -> ", cur->data);
        cur = cur->next;
    } while (cur != tail->next);
    printf("(처음으로)\n");
}

// 03번: 원형 연결 리스트에서 data를 가진 노드를 찾아 반환
ListNode* search(ListNode* L, int data) {
    if (L == NULL) return NULL;
    ListNode* cur = L->next; // head
    do {
        if (cur->data == data) return cur;
        cur = cur->next;
    } while (cur != L->next);
    return NULL;
}

// 04번: 원형 연결 리스트에 저장된 데이터 개수 반환
int get_size(ListNode* L) {
    if (L == NULL) return 0;
    int count = 0;
    ListNode* cur = L->next;
    do {
        count++;
        cur = cur->next;
    } while (cur != L->next);
    return count;
}

// ============================================================
// 이중 연결 리스트 노드 (문제 06, 07)
// ============================================================
typedef struct DListNode {
    int data;
    struct DListNode* prev;
    struct DListNode* next;
} DListNode;

// 이중 연결 리스트 헤드에 노드 삽입
DListNode* insertDList(DListNode* head, int data) {
    DListNode* newNode = (DListNode*)malloc(sizeof(DListNode));
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = head;
    if (head != NULL) head->prev = newNode;
    return newNode;
}

// 이중 연결 리스트 정방향 출력
void printDList(DListNode* head) {
    DListNode* cur = head;
    while (cur != NULL) {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}

// 06번: 이중 연결 리스트를 역순으로 출력
void printDListReverse(DListNode* head) {
    if (head == NULL) { printf("(빈 리스트)\n"); return; }
    // tail까지 이동
    DListNode* tail = head;
    while (tail->next != NULL) tail = tail->next;
    // tail부터 역순 출력
    DListNode* cur = tail;
    while (cur != NULL) {
        printf("%d ", cur->data);
        cur = cur->prev;
    }
    printf("\n");
}

// 07번: 이중 연결 리스트에서 data를 가진 노드를 찾아 반환
DListNode* searchDList(DListNode* L, int data) {
    DListNode* cur = L;
    while (cur != NULL) {
        if (cur->data == data) return cur;
        cur = cur->next;
    }
    return NULL;
}

// ============================================================
// 메모리 해제 함수
// ============================================================
void freeCircular(ListNode* tail) {
    if (tail == NULL) return;
    ListNode* head = tail->next;
    ListNode* cur = head;
    do {
        ListNode* tmp = cur;
        cur = cur->next;
        free(tmp);
    } while (cur != head);
}

void freeDList(DListNode* head) {
    while (head != NULL) {
        DListNode* tmp = head;
        head = head->next;
        free(tmp);
    }
}

// ============================================================
// main
// ============================================================
int main() {
    // --------------------------------------------------------
    // 문제 03: 원형 연결 리스트 탐색 search()
    // --------------------------------------------------------
    printf("=== 문제 03: 원형 연결 리스트 search() ===\n");
    ListNode* tail = NULL;
    tail = addToCircular(tail, 10);
    tail = addToCircular(tail, 20);
    tail = addToCircular(tail, 30);
    tail = addToCircular(tail, 40);
    printf("원형 연결 리스트: ");
    printCircular(tail);

    int target = 30;
    ListNode* found = search(tail, target);
    if (found != NULL)
        printf("search(%d) 결과: 노드 발견 (data = %d)\n", target, found->data);
    else
        printf("search(%d) 결과: 노드 없음\n", target);

    target = 99;
    found = search(tail, target);
    if (found != NULL)
        printf("search(%d) 결과: 노드 발견 (data = %d)\n", target, found->data);
    else
        printf("search(%d) 결과: 노드 없음\n", target);

    // --------------------------------------------------------
    // 문제 04: 원형 연결 리스트 크기 get_size()
    // --------------------------------------------------------
    printf("\n=== 문제 04: 원형 연결 리스트 get_size() ===\n");
    printf("원형 연결 리스트 노드 개수: %d\n", get_size(tail));
    freeCircular(tail);

    // --------------------------------------------------------
    // 문제 06: 이중 연결 리스트 역순 출력
    // --------------------------------------------------------
    printf("\n=== 문제 06: 이중 연결 리스트 역순 출력 ===\n");
    int n;
    printf("데이터의 개수를 입력하시오 : ");
    scanf("%d", &n);

    DListNode* dhead = NULL;
    // 입력 순서대로 뒤에 붙이기 위해 순서 유지
    DListNode* dtail = NULL;
    for (int i = 1; i <= n; i++) {
        int val;
        printf("노드 #%d의 데이터를 입력하시오: ", i);
        scanf("%d", &val);
        DListNode* newNode = (DListNode*)malloc(sizeof(DListNode));
        newNode->data = val;
        newNode->next = NULL;
        newNode->prev = dtail;
        if (dtail == NULL) dhead = newNode;
        else dtail->next = newNode;
        dtail = newNode;
    }
    printf("데이터를 역순으로 출력: ");
    printDListReverse(dhead);

    // --------------------------------------------------------
    // 문제 07: 이중 연결 리스트 탐색 search()
    // --------------------------------------------------------
    printf("\n=== 문제 07: 이중 연결 리스트 searchDList() ===\n");
    printf("현재 이중 연결 리스트: ");
    printDList(dhead);

    int dtarget;
    printf("탐색할 데이터를 입력하시오: ");
    scanf("%d", &dtarget);
    DListNode* dresult = searchDList(dhead, dtarget);
    if (dresult != NULL)
        printf("searchDList(%d) 결과: 노드 발견 (data = %d)\n", dtarget, dresult->data);
    else
        printf("searchDList(%d) 결과: 노드 없음\n", dtarget);

    freeDList(dhead);
    return 0;
}
