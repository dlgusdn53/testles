#include <stdio.h>
#include <stdlib.h>

// 트리 노드 구조체
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

// 새 노드 생성
Node* createNode(int data) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// 전위 순회 (Preorder): 루트 -> 왼쪽 -> 오른쪽
void preorder(Node* root) {
    if (root == NULL) return;
    printf("%02d ", root->data);
    preorder(root->left);
    preorder(root->right);
}

// 중위 순회 (Inorder): 왼쪽 -> 루트 -> 오른쪽
void inorder(Node* root) {
    if (root == NULL) return;
    inorder(root->left);
    printf("%02d ", root->data);
    inorder(root->right);
}

// 후위 순회 (Postorder): 왼쪽 -> 오른쪽 -> 루트
void postorder(Node* root) {
    if (root == NULL) return;
    postorder(root->left);
    postorder(root->right);
    printf("%02d ", root->data);
}

int main() {
    /*
     * 트리 구조:
     *
     *         17
     *        /  \
     *       15   93
     *      /    /  \
     *     05   35   95
     *         /
     *        22
     */

    // 노드 생성
    Node* root = createNode(17);
    root->left  = createNode(15);
    root->right = createNode(93);

    root->left->left   = createNode(5);

    root->right->left  = createNode(35);
    root->right->right = createNode(95);

    root->right->left->left = createNode(22);

    // 순회 결과 출력
    printf("전위 순회 (Preorder)  : ");
    preorder(root);
    printf("\n");

    printf("중위 순회 (Inorder)   : ");
    inorder(root);
    printf("\n");

    printf("후위 순회 (Postorder) : ");
    postorder(root);
    printf("\n");

    return 0;
}
